module.exports = {
    plugins: [
        require('autoprefixer')({browsers: ['last 2 version', 'IE 10']})
    ]
  }